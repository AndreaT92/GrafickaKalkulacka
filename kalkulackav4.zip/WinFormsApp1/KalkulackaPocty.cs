﻿namespace GrafickaKalkulacka
{
    internal class KalkulackaPocty
    {

        private double _vysledek = double.NaN;
        private string _znamenko = string.Empty;
        private string _historie = string.Empty;

        public void Operace(double cislo, string operatorZnak)
        {
            if (!string.IsNullOrEmpty(_znamenko))
            {

                RovnaSe(cislo);
                _historie = _vysledek + operatorZnak;


            }
            else
            {

                _vysledek = cislo;
                _historie += _vysledek + operatorZnak;

            }


            _znamenko = operatorZnak;

        }


        public void RovnaSe(double cislo)
        {
            switch (_znamenko)
            {
                case "+":
                    _vysledek += cislo;
                    break;
                case "-":
                    _vysledek -= cislo;
                    break;
                case "*":
                    _vysledek *= cislo;
                    break;
                case "/":
                    if (cislo != 0)
                    {
                        _vysledek /= cislo;
                    }
                    else
                    {

                        _vysledek = double.NaN;
                    }
                    break;
                default:

                    _vysledek = cislo;
                    break;
            }
            _historie += cislo + "=" + _vysledek;
            _znamenko = string.Empty;

        }

        public double ZiskejVysledek()
        {
            return _vysledek;
        }

        public string ZiskejHistorii()
        {
            return _historie;
        }

        public void RestartHistorie()
        {
            _historie = string.Empty;
        }
    }
}



